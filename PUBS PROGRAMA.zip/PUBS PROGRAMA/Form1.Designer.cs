namespace PUBS_PROGRAMA
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblAccion = new System.Windows.Forms.Label();
            this.dgvResultados = new System.Windows.Forms.DataGridView();
            this.btnLimpiar = new System.Windows.Forms.Button();
            
            this.btnSeleccion1 = new System.Windows.Forms.Button();
            this.btnSeleccion2 = new System.Windows.Forms.Button();
            this.btnSeleccion3 = new System.Windows.Forms.Button();
            
            this.btnProyeccion1 = new System.Windows.Forms.Button();
            this.btnProyeccion2 = new System.Windows.Forms.Button();
            this.btnProyeccion3 = new System.Windows.Forms.Button();
            
            this.btnRenombramiento1 = new System.Windows.Forms.Button();
            this.btnRenombramiento2 = new System.Windows.Forms.Button();
            this.btnRenombramiento3 = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).BeginInit();
            this.SuspendLayout();

            // lblTitulo
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(20, 20);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(650, 30);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "OPERACIONES ÁLGEBRA RELACIONAL - BASE DE DATOS PUBS";

            // lblAccion
            this.lblAccion.AutoSize = true;
            this.lblAccion.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccion.ForeColor = System.Drawing.Color.Blue;
            this.lblAccion.Location = new System.Drawing.Point(20, 340);
            this.lblAccion.Name = "lblAccion";
            this.lblAccion.Size = new System.Drawing.Size(200, 19);
            this.lblAccion.TabIndex = 1;
            this.lblAccion.Text = "Esperando acción...";

            // dgvResultados
            this.dgvResultados.AllowUserToAddRows = false;
            this.dgvResultados.AllowUserToDeleteRows = false;
            this.dgvResultados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResultados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultados.Location = new System.Drawing.Point(24, 370);
            this.dgvResultados.Name = "dgvResultados";
            this.dgvResultados.ReadOnly = true;
            this.dgvResultados.Size = new System.Drawing.Size(950, 250);
            this.dgvResultados.TabIndex = 11;

            // btnLimpiar
            this.btnLimpiar.Location = new System.Drawing.Point(850, 330);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(124, 30);
            this.btnLimpiar.TabIndex = 12;
            this.btnLimpiar.Text = "Limpiar Resultados";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);

            // Configuraciones Comunes Botones
            int btnWidth = 300;
            int btnHeight = 50;
            int startX = 24;
            int gapX = 320;

            // btnSeleccion1
            this.btnSeleccion1.Location = new System.Drawing.Point(startX, 80);
            this.btnSeleccion1.Name = "btnSeleccion1";
            this.btnSeleccion1.Size = new System.Drawing.Size(btnWidth, btnHeight);
            this.btnSeleccion1.TabIndex = 2;
            this.btnSeleccion1.Text = "1. Selección: Autores de California (State = \'CA\')";
            this.btnSeleccion1.UseVisualStyleBackColor = true;
            this.btnSeleccion1.Click += new System.EventHandler(this.btnSeleccion1_Click);

            // btnSeleccion2
            this.btnSeleccion2.Location = new System.Drawing.Point(startX + gapX, 80);
            this.btnSeleccion2.Name = "btnSeleccion2";
            this.btnSeleccion2.Size = new System.Drawing.Size(btnWidth, btnHeight);
            this.btnSeleccion2.TabIndex = 3;
            this.btnSeleccion2.Text = "2. Selección: Títulos con precio > 50";
            this.btnSeleccion2.UseVisualStyleBackColor = true;
            this.btnSeleccion2.Click += new System.EventHandler(this.btnSeleccion2_Click);

            // btnSeleccion3
            this.btnSeleccion3.Location = new System.Drawing.Point(startX + gapX * 2, 80);
            this.btnSeleccion3.Name = "btnSeleccion3";
            this.btnSeleccion3.Size = new System.Drawing.Size(btnWidth, btnHeight);
            this.btnSeleccion3.TabIndex = 4;
            this.btnSeleccion3.Text = "3. Selección: Publishers de USA (Country = \'USA\')";
            this.btnSeleccion3.UseVisualStyleBackColor = true;
            this.btnSeleccion3.Click += new System.EventHandler(this.btnSeleccion3_Click);

            // btnProyeccion1
            this.btnProyeccion1.Location = new System.Drawing.Point(startX, 150);
            this.btnProyeccion1.Name = "btnProyeccion1";
            this.btnProyeccion1.Size = new System.Drawing.Size(btnWidth, btnHeight);
            this.btnProyeccion1.TabIndex = 5;
            this.btnProyeccion1.Text = "1. Proyección: Nombre, Apellido y Teléfono de Autores";
            this.btnProyeccion1.UseVisualStyleBackColor = true;
            this.btnProyeccion1.Click += new System.EventHandler(this.btnProyeccion1_Click);

            // btnProyeccion2
            this.btnProyeccion2.Location = new System.Drawing.Point(startX + gapX, 150);
            this.btnProyeccion2.Name = "btnProyeccion2";
            this.btnProyeccion2.Size = new System.Drawing.Size(btnWidth, btnHeight);
            this.btnProyeccion2.TabIndex = 6;
            this.btnProyeccion2.Text = "2. Proyección: Título, Precio y Ventas de Libros";
            this.btnProyeccion2.UseVisualStyleBackColor = true;
            this.btnProyeccion2.Click += new System.EventHandler(this.btnProyeccion2_Click);

            // btnProyeccion3
            this.btnProyeccion3.Location = new System.Drawing.Point(startX + gapX * 2, 150);
            this.btnProyeccion3.Name = "btnProyeccion3";
            this.btnProyeccion3.Size = new System.Drawing.Size(btnWidth, btnHeight);
            this.btnProyeccion3.TabIndex = 7;
            this.btnProyeccion3.Text = "3. Proyección: Nombre, Ciudad y País de Publishers";
            this.btnProyeccion3.UseVisualStyleBackColor = true;
            this.btnProyeccion3.Click += new System.EventHandler(this.btnProyeccion3_Click);

            // btnRenombramiento1
            this.btnRenombramiento1.Location = new System.Drawing.Point(startX, 220);
            this.btnRenombramiento1.Name = "btnRenombramiento1";
            this.btnRenombramiento1.Size = new System.Drawing.Size(btnWidth, btnHeight);
            this.btnRenombramiento1.TabIndex = 8;
            this.btnRenombramiento1.Text = "1. Renombramiento: Autores (Nombre, Apellido, Teléfono, Ciudad)";
            this.btnRenombramiento1.UseVisualStyleBackColor = true;
            this.btnRenombramiento1.Click += new System.EventHandler(this.btnRenombramiento1_Click);

            // btnRenombramiento2
            this.btnRenombramiento2.Location = new System.Drawing.Point(startX + gapX, 220);
            this.btnRenombramiento2.Name = "btnRenombramiento2";
            this.btnRenombramiento2.Size = new System.Drawing.Size(btnWidth, btnHeight);
            this.btnRenombramiento2.TabIndex = 9;
            this.btnRenombramiento2.Text = "2. Renombramiento: Títulos (NombreLibro, Precio, VentasAnio, Fecha)";
            this.btnRenombramiento2.UseVisualStyleBackColor = true;
            this.btnRenombramiento2.Click += new System.EventHandler(this.btnRenombramiento2_Click);

            // btnRenombramiento3
            this.btnRenombramiento3.Location = new System.Drawing.Point(startX + gapX * 2, 220);
            this.btnRenombramiento3.Name = "btnRenombramiento3";
            this.btnRenombramiento3.Size = new System.Drawing.Size(btnWidth, btnHeight);
            this.btnRenombramiento3.TabIndex = 10;
            this.btnRenombramiento3.Text = "3. Renombramiento: Publishers (Editorial, Ciudad, País)";
            this.btnRenombramiento3.UseVisualStyleBackColor = true;
            this.btnRenombramiento3.Click += new System.EventHandler(this.btnRenombramiento3_Click);

            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 650);
            
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.dgvResultados);
            this.Controls.Add(this.lblAccion);
            this.Controls.Add(this.lblTitulo);
            
            this.Controls.Add(this.btnSeleccion1);
            this.Controls.Add(this.btnSeleccion2);
            this.Controls.Add(this.btnSeleccion3);
            
            this.Controls.Add(this.btnProyeccion1);
            this.Controls.Add(this.btnProyeccion2);
            this.Controls.Add(this.btnProyeccion3);
            
            this.Controls.Add(this.btnRenombramiento1);
            this.Controls.Add(this.btnRenombramiento2);
            this.Controls.Add(this.btnRenombramiento3);

            this.Name = "Form1";
            this.Text = "Operaciones de Álgebra Relacional - Pubs";
            
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblAccion;
        private System.Windows.Forms.DataGridView dgvResultados;
        private System.Windows.Forms.Button btnLimpiar;
        
        private System.Windows.Forms.Button btnSeleccion1;
        private System.Windows.Forms.Button btnSeleccion2;
        private System.Windows.Forms.Button btnSeleccion3;
        
        private System.Windows.Forms.Button btnProyeccion1;
        private System.Windows.Forms.Button btnProyeccion2;
        private System.Windows.Forms.Button btnProyeccion3;
        
        private System.Windows.Forms.Button btnRenombramiento1;
        private System.Windows.Forms.Button btnRenombramiento2;
        private System.Windows.Forms.Button btnRenombramiento3;
    }
}
