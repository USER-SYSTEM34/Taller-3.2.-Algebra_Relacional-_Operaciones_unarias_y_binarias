using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace PUBS_PROGRAMA
{
    public partial class Form1 : Form
    {
        // Instancia del contexto de la base de datos Entity Framework
        private pubsEntities db = new pubsEntities();

        public Form1()
        {
            InitializeComponent();
        }

        // ==========================================
        // 1. OPERACIONES DE SELECCIÓN (σ)
        // ==========================================

        private void btnSeleccion1_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Selección (σ) - Autores de California (State = 'CA')";

            var resultado = db.authors
                              .Where(a => a.state == "CA")
                              .ToList();

            dgvResultados.DataSource = resultado;
        }

        private void btnSeleccion2_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Selección (σ) - Títulos con precio > 50";

            var resultado = db.titles
                              .Where(t => t.price > 50)
                              .ToList();

            dgvResultados.DataSource = resultado;
        }

        private void btnSeleccion3_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Selección (σ) - Publishers de USA (Country = 'USA')";

            var resultado = db.publishers
                              .Where(p => p.country == "USA")
                              .ToList();

            dgvResultados.DataSource = resultado;
        }

        // ==========================================
        // 2. OPERACIONES DE PROYECCIÓN (π)
        // ==========================================

        private void btnProyeccion1_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Proyección (π) - Nombre, Apellido y Teléfono de Autores";

            var resultado = db.authors
                              .Select(a => new
                              {
                                  Nombre = a.au_fname,
                                  Apellido = a.au_lname,
                                  Telefono = a.phone
                              })
                              .ToList();

            dgvResultados.DataSource = resultado;
        }

        private void btnProyeccion2_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Proyección (π) - Título, Precio y Ventas de Libros";

            var resultado = db.titles
                              .Select(t => new
                              {
                                  Titulo = t.title,
                                  Precio = t.price,
                                  Ventas = t.ytd_sales
                              })
                              .ToList();

            dgvResultados.DataSource = resultado;
        }

        private void btnProyeccion3_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Proyección (π) - Nombre, Ciudad y País de Publishers";

            var resultado = db.publishers
                              .Select(p => new
                              {
                                  NombrePublisher = p.pub_name,
                                  Ciudad = p.city,
                                  Pais = p.country
                              })
                              .ToList();

            dgvResultados.DataSource = resultado;
        }

        // ==========================================
        // 3. OPERACIONES DE RENOMBRAMIENTO (ρ)
        // ==========================================

        private void btnRenombramiento1_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Renombramiento (ρ) - Autores (Nombre, Apellido, Teléfono, Ciudad)";

            var resultado = db.authors
                              .Select(a => new
                              {
                                  Nombre = a.au_fname,
                                  Apellido = a.au_lname,
                                  Telefono = a.phone,
                                  Ciudad = a.city
                              })
                              .ToList();

            dgvResultados.DataSource = resultado;
        }

        private void btnRenombramiento2_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Renombramiento (ρ) - Títulos (NombreLibro, Precio, VentasAnio, Fecha)";

            var resultado = db.titles
                              .Select(t => new
                              {
                                  NombreLibro = t.title,
                                  Precio = t.price,
                                  VentasAnio = t.ytd_sales,
                                  Fecha = t.pubdate
                              })
                              .ToList();

            dgvResultados.DataSource = resultado;
        }

        private void btnRenombramiento3_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Renombramiento (ρ) - Publishers (Editorial, Ciudad, País)";

            var resultado = db.publishers
                              .Select(p => new
                              {
                                  Editorial = p.pub_name,
                                  Ciudad = p.city,
                                  Pais = p.country
                              })
                              .ToList();

            dgvResultados.DataSource = resultado;
        }

        // ==========================================
        // 4. LIMPIEZA DE DATOS
        // ==========================================

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            dgvResultados.DataSource = null;
            lblAccion.Text = "Resultados limpiados. Esperando nueva operación...";
        }
    }
}
