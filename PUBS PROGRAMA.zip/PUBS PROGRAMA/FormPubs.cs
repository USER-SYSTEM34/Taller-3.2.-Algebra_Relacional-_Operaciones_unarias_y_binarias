using System;
using System.Data;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;

namespace PUBS_PROGRAMA
{
    public partial class FormPubs : Form
    {
        // Instancia del contexto de la base de datos Entity Framework
        private pubsEntities db = new pubsEntities();

        public FormPubs()
        {
            InitializeComponent();
        }

        #region Código del Diseñador
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblAccion = new System.Windows.Forms.Label();
            this.dgvResultados = new System.Windows.Forms.DataGridView();
            
            this.gbSeleccion = new System.Windows.Forms.GroupBox();
            this.btnSeleccion1 = new System.Windows.Forms.Button();
            this.btnSeleccion2 = new System.Windows.Forms.Button();
            this.btnSeleccion3 = new System.Windows.Forms.Button();
            
            this.gbProyeccion = new System.Windows.Forms.GroupBox();
            this.btnProyeccion1 = new System.Windows.Forms.Button();
            this.btnProyeccion2 = new System.Windows.Forms.Button();
            this.btnProyeccion3 = new System.Windows.Forms.Button();
            
            this.gbRenombramiento = new System.Windows.Forms.GroupBox();
            this.btnRenombramiento1 = new System.Windows.Forms.Button();
            this.btnRenombramiento2 = new System.Windows.Forms.Button();
            this.btnRenombramiento3 = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).BeginInit();
            
            this.gbSeleccion.SuspendLayout();
            this.gbProyeccion.SuspendLayout();
            this.gbRenombramiento.SuspendLayout();
            this.SuspendLayout();

            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(20, 20);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(650, 30);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "OPERACIONES ÁLGEBRA RELACIONAL - BASE DE DATOS PUBS";

            // 
            // lblAccion
            // 
            this.lblAccion.AutoSize = true;
            this.lblAccion.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccion.ForeColor = System.Drawing.Color.MediumBlue;
            this.lblAccion.Location = new System.Drawing.Point(20, 280);
            this.lblAccion.Name = "lblAccion";
            this.lblAccion.Size = new System.Drawing.Size(200, 19);
            this.lblAccion.TabIndex = 1;
            this.lblAccion.Text = "Esperando acción...";

            // 
            // dgvResultados
            // 
            this.dgvResultados.AllowUserToAddRows = false;
            this.dgvResultados.AllowUserToDeleteRows = false;
            this.dgvResultados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvResultados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultados.Location = new System.Drawing.Point(20, 310);
            this.dgvResultados.Name = "dgvResultados";
            this.dgvResultados.ReadOnly = true;
            this.dgvResultados.Size = new System.Drawing.Size(940, 330);
            this.dgvResultados.TabIndex = 2;

            // 
            // gbSeleccion
            // 
            this.gbSeleccion.Controls.Add(this.btnSeleccion1);
            this.gbSeleccion.Controls.Add(this.btnSeleccion2);
            this.gbSeleccion.Controls.Add(this.btnSeleccion3);
            this.gbSeleccion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSeleccion.Location = new System.Drawing.Point(20, 70);
            this.gbSeleccion.Name = "gbSeleccion";
            this.gbSeleccion.Size = new System.Drawing.Size(300, 190);
            this.gbSeleccion.TabIndex = 3;
            this.gbSeleccion.TabStop = false;
            this.gbSeleccion.Text = "1. Selección (σ)";

            // 
            // btnSeleccion1
            // 
            this.btnSeleccion1.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSeleccion1.Location = new System.Drawing.Point(15, 30);
            this.btnSeleccion1.Name = "btnSeleccion1";
            this.btnSeleccion1.Size = new System.Drawing.Size(270, 40);
            this.btnSeleccion1.TabIndex = 0;
            this.btnSeleccion1.Text = "1. Autores de California (State = \'CA\')";
            this.btnSeleccion1.UseVisualStyleBackColor = true;
            this.btnSeleccion1.Click += new System.EventHandler(this.btnSeleccion1_Click);

            // 
            // btnSeleccion2
            // 
            this.btnSeleccion2.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSeleccion2.Location = new System.Drawing.Point(15, 80);
            this.btnSeleccion2.Name = "btnSeleccion2";
            this.btnSeleccion2.Size = new System.Drawing.Size(270, 40);
            this.btnSeleccion2.TabIndex = 1;
            this.btnSeleccion2.Text = "2. Títulos con precio > 50";
            this.btnSeleccion2.UseVisualStyleBackColor = true;
            this.btnSeleccion2.Click += new System.EventHandler(this.btnSeleccion2_Click);

            // 
            // btnSeleccion3
            // 
            this.btnSeleccion3.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSeleccion3.Location = new System.Drawing.Point(15, 130);
            this.btnSeleccion3.Name = "btnSeleccion3";
            this.btnSeleccion3.Size = new System.Drawing.Size(270, 40);
            this.btnSeleccion3.TabIndex = 2;
            this.btnSeleccion3.Text = "3. Publishers de USA (Country = \'USA\')";
            this.btnSeleccion3.UseVisualStyleBackColor = true;
            this.btnSeleccion3.Click += new System.EventHandler(this.btnSeleccion3_Click);

            // 
            // gbProyeccion
            // 
            this.gbProyeccion.Controls.Add(this.btnProyeccion1);
            this.gbProyeccion.Controls.Add(this.btnProyeccion2);
            this.gbProyeccion.Controls.Add(this.btnProyeccion3);
            this.gbProyeccion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbProyeccion.Location = new System.Drawing.Point(340, 70);
            this.gbProyeccion.Name = "gbProyeccion";
            this.gbProyeccion.Size = new System.Drawing.Size(300, 190);
            this.gbProyeccion.TabIndex = 4;
            this.gbProyeccion.TabStop = false;
            this.gbProyeccion.Text = "2. Proyección (π)";

            // 
            // btnProyeccion1
            // 
            this.btnProyeccion1.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProyeccion1.Location = new System.Drawing.Point(15, 30);
            this.btnProyeccion1.Name = "btnProyeccion1";
            this.btnProyeccion1.Size = new System.Drawing.Size(270, 40);
            this.btnProyeccion1.TabIndex = 0;
            this.btnProyeccion1.Text = "1. Nombre, Apellido y Teléfono de Autores";
            this.btnProyeccion1.UseVisualStyleBackColor = true;
            this.btnProyeccion1.Click += new System.EventHandler(this.btnProyeccion1_Click);

            // 
            // btnProyeccion2
            // 
            this.btnProyeccion2.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProyeccion2.Location = new System.Drawing.Point(15, 80);
            this.btnProyeccion2.Name = "btnProyeccion2";
            this.btnProyeccion2.Size = new System.Drawing.Size(270, 40);
            this.btnProyeccion2.TabIndex = 1;
            this.btnProyeccion2.Text = "2. Título, Precio y Ventas de Libros";
            this.btnProyeccion2.UseVisualStyleBackColor = true;
            this.btnProyeccion2.Click += new System.EventHandler(this.btnProyeccion2_Click);

            // 
            // btnProyeccion3
            // 
            this.btnProyeccion3.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProyeccion3.Location = new System.Drawing.Point(15, 130);
            this.btnProyeccion3.Name = "btnProyeccion3";
            this.btnProyeccion3.Size = new System.Drawing.Size(270, 40);
            this.btnProyeccion3.TabIndex = 2;
            this.btnProyeccion3.Text = "3. Nombre, Ciudad y País de Publishers";
            this.btnProyeccion3.UseVisualStyleBackColor = true;
            this.btnProyeccion3.Click += new System.EventHandler(this.btnProyeccion3_Click);

            // 
            // gbRenombramiento
            // 
            this.gbRenombramiento.Controls.Add(this.btnRenombramiento1);
            this.gbRenombramiento.Controls.Add(this.btnRenombramiento2);
            this.gbRenombramiento.Controls.Add(this.btnRenombramiento3);
            this.gbRenombramiento.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbRenombramiento.Location = new System.Drawing.Point(660, 70);
            this.gbRenombramiento.Name = "gbRenombramiento";
            this.gbRenombramiento.Size = new System.Drawing.Size(300, 190);
            this.gbRenombramiento.TabIndex = 5;
            this.gbRenombramiento.TabStop = false;
            this.gbRenombramiento.Text = "3. Renombramiento (ρ)";

            // 
            // btnRenombramiento1
            // 
            this.btnRenombramiento1.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRenombramiento1.Location = new System.Drawing.Point(15, 30);
            this.btnRenombramiento1.Name = "btnRenombramiento1";
            this.btnRenombramiento1.Size = new System.Drawing.Size(270, 40);
            this.btnRenombramiento1.TabIndex = 0;
            this.btnRenombramiento1.Text = "1. Autores (Nombre, Apellido, Teléfono, Ciudad)";
            this.btnRenombramiento1.UseVisualStyleBackColor = true;
            this.btnRenombramiento1.Click += new System.EventHandler(this.btnRenombramiento1_Click);

            // 
            // btnRenombramiento2
            // 
            this.btnRenombramiento2.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRenombramiento2.Location = new System.Drawing.Point(15, 80);
            this.btnRenombramiento2.Name = "btnRenombramiento2";
            this.btnRenombramiento2.Size = new System.Drawing.Size(270, 40);
            this.btnRenombramiento2.TabIndex = 1;
            this.btnRenombramiento2.Text = "2. Títulos (NombreLibro, Precio, VentasAnio, Fecha)";
            this.btnRenombramiento2.UseVisualStyleBackColor = true;
            this.btnRenombramiento2.Click += new System.EventHandler(this.btnRenombramiento2_Click);

            // 
            // btnRenombramiento3
            // 
            this.btnRenombramiento3.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRenombramiento3.Location = new System.Drawing.Point(15, 130);
            this.btnRenombramiento3.Name = "btnRenombramiento3";
            this.btnRenombramiento3.Size = new System.Drawing.Size(270, 40);
            this.btnRenombramiento3.TabIndex = 2;
            this.btnRenombramiento3.Text = "3. Publishers (Editorial, Ciudad, País)";
            this.btnRenombramiento3.UseVisualStyleBackColor = true;
            this.btnRenombramiento3.Click += new System.EventHandler(this.btnRenombramiento3_Click);

            // 
            // FormPubs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 661);
            this.Controls.Add(this.gbRenombramiento);
            this.Controls.Add(this.gbProyeccion);
            this.Controls.Add(this.gbSeleccion);
            this.Controls.Add(this.dgvResultados);
            this.Controls.Add(this.lblAccion);
            this.Controls.Add(this.lblTitulo);
            this.Name = "FormPubs";
            this.Text = "Operaciones de Álgebra Relacional - Pubs";
            
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultados)).EndInit();
            this.gbSeleccion.ResumeLayout(false);
            this.gbProyeccion.ResumeLayout(false);
            this.gbRenombramiento.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblAccion;
        private System.Windows.Forms.DataGridView dgvResultados;
        
        private System.Windows.Forms.GroupBox gbSeleccion;
        private System.Windows.Forms.Button btnSeleccion1;
        private System.Windows.Forms.Button btnSeleccion2;
        private System.Windows.Forms.Button btnSeleccion3;
        
        private System.Windows.Forms.GroupBox gbProyeccion;
        private System.Windows.Forms.Button btnProyeccion1;
        private System.Windows.Forms.Button btnProyeccion2;
        private System.Windows.Forms.Button btnProyeccion3;
        
        private System.Windows.Forms.GroupBox gbRenombramiento;
        private System.Windows.Forms.Button btnRenombramiento1;
        private System.Windows.Forms.Button btnRenombramiento2;
        private System.Windows.Forms.Button btnRenombramiento3;
        #endregion

        // ==========================================
        // 1. OPERACIONES DE SELECCIÓN (σ)
        // ==========================================
        private void btnSeleccion1_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Selección (σ) - Autores de California (State = 'CA')";
            var resultado = db.authors.Where(a => a.state == "CA").ToList();
            dgvResultados.DataSource = resultado;
        }

        private void btnSeleccion2_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Selección (σ) - Títulos con precio > 50";
            var resultado = db.titles.Where(t => t.price > 50).ToList();
            dgvResultados.DataSource = resultado;
        }

        private void btnSeleccion3_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Selección (σ) - Publishers de USA (Country = 'USA')";
            var resultado = db.publishers.Where(p => p.country == "USA").ToList();
            dgvResultados.DataSource = resultado;
        }

        // ==========================================
        // 2. OPERACIONES DE PROYECCIÓN (π)
        // ==========================================
        private void btnProyeccion1_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Proyección (π) - Nombre, Apellido y Teléfono de Autores";
            var resultado = db.authors.Select(a => new { Nombre = a.au_fname, Apellido = a.au_lname, Telefono = a.phone }).ToList();
            dgvResultados.DataSource = resultado;
        }

        private void btnProyeccion2_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Proyección (π) - Título, Precio y Ventas de Libros";
            var resultado = db.titles.Select(t => new { Titulo = t.title, Precio = t.price, Ventas = t.ytd_sales }).ToList();
            dgvResultados.DataSource = resultado;
        }

        private void btnProyeccion3_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Proyección (π) - Nombre, Ciudad y País de Publishers";
            var resultado = db.publishers.Select(p => new { NombrePublisher = p.pub_name, Ciudad = p.city, Pais = p.country }).ToList();
            dgvResultados.DataSource = resultado;
        }

        // ==========================================
        // 3. OPERACIONES DE RENOMBRAMIENTO (ρ)
        // ==========================================
        private void btnRenombramiento1_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Renombramiento (ρ) - Autores (Nombre, Apellido, Teléfono, Ciudad)";
            var resultado = db.authors.Select(a => new { Nombre = a.au_fname, Apellido = a.au_lname, Telefono = a.phone, Ciudad = a.city }).ToList();
            dgvResultados.DataSource = resultado;
        }

        private void btnRenombramiento2_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Renombramiento (ρ) - Títulos (NombreLibro, Precio, VentasAnio, Fecha)";
            var resultado = db.titles.Select(t => new { NombreLibro = t.title, Precio = t.price, VentasAnio = t.ytd_sales, Fecha = t.pubdate }).ToList();
            dgvResultados.DataSource = resultado;
        }

        private void btnRenombramiento3_Click(object sender, EventArgs e)
        {
            lblAccion.Text = "Operación: Renombramiento (ρ) - Publishers (Editorial, Ciudad, País)";
            var resultado = db.publishers.Select(p => new { Editorial = p.pub_name, Ciudad = p.city, Pais = p.country }).ToList();
            dgvResultados.DataSource = resultado;
        }
    }
}
